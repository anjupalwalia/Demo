# Playwright.dev Test Plan

## Application Overview

Test plan for the playwright.dev marketing and documentation website (https://playwright.dev/). The site serves as the homepage and docs portal for the Playwright testing framework. Key features include: homepage hero section, top navigation (Docs, MCP, CLI, API, language switcher), theme toggle, search, social links, content sections ("Built for testing", "Built for AI agents", "Powerful tooling"), and a full documentation sidebar for the Installation / Getting Started pages.

## Test Scenarios

### 1. Homepage

**Seed:** `tests/example.spec.js`

#### 1.1. has title

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The page title should contain the word 'Playwright'

#### 1.2. homepage hero heading is visible

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The main h1 heading 'Playwright enables reliable web automation for testing, scripting, and AI agents.' is visible in the hero banner

#### 1.3. Get Started link navigates to Installation page

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Click the 'Get started' link in the hero section
    - expect: The browser navigates to https://playwright.dev/docs/intro
  3. Inspect the page heading
    - expect: A heading with the name 'Installation' is visible on the page

#### 1.4. hero section language links are present

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Inspect the hero paragraph for language links
    - expect: Links for TypeScript, Python, .NET, and Java are all visible inside the hero paragraph

#### 1.5. GitHub star button is visible

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Inspect the hero section for the GitHub star widget
    - expect: A 'Star microsoft/playwright on GitHub' link and a stargazers count link (92k+) are both visible

#### 1.6. product cards section is rendered

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Scroll to the product cards area below the hero
    - expect: Three product headings are visible: 'Playwright Test', 'Playwright CLI', and 'Playwright MCP'
  3. Verify the install command for each product card
    - expect: 'npm init playwright@latest', 'npm i -g @playwright/cli@latest', and 'npx @playwright/mcp@latest' code snippets are visible

#### 1.7. Testing documentation link on product card navigates correctly

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Click the 'Testing documentation' link within the Playwright Test product card
    - expect: The browser navigates to /docs/intro and the Installation heading is visible

#### 1.8. Built for testing section displays all feature headings

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Scroll to the 'Built for testing' section
    - expect: The h2 'Built for testing' is visible
  3. Verify all feature headings in the section
    - expect: 'Auto-wait and web-first assertions', 'Test isolation', 'Resilient locators', and 'Parallelism and sharding' headings are all visible

#### 1.9. Built for AI agents section displays all feature headings

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Scroll to the 'Built for AI agents' section
    - expect: The h2 'Built for AI agents' is visible
  3. Verify all feature headings
    - expect: 'Accessibility snapshots, not screenshots', 'MCP server', 'CLI for coding agents', and 'Session monitoring' headings are all visible

#### 1.10. Powerful tooling section tool links are present

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Scroll to the 'Powerful tooling' section
    - expect: The h2 'Powerful tooling' is visible
  3. Verify links to each tool
    - expect: 'Test generator', 'Trace Viewer', and 'VS Code extension' links are all present and clickable

#### 1.11. company logo list is displayed

**File:** `tests/playwright-dev/homepage.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads successfully
  2. Scroll to the 'Chosen by companies and open source projects' section
    - expect: The section heading is visible and a list of company logos is rendered (e.g., VS Code, Bing, Outlook, Adobe, Material UI)

### 2. Top Navigation

**Seed:** `tests/example.spec.js`

#### 2.1. Docs navigation link loads documentation

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Click the 'Docs' link in the top navigation
    - expect: The browser navigates to /docs/intro and the Installation page is displayed

#### 2.2. API navigation link loads API reference

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Click the 'API' link in the top navigation
    - expect: The browser navigates to /docs/api/class-playwright

#### 2.3. MCP navigation link loads MCP introduction

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Click the 'MCP' link in the top navigation
    - expect: The browser navigates to /mcp/introduction

#### 2.4. CLI navigation link loads CLI introduction

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Click the 'CLI' link in the top navigation
    - expect: The browser navigates to /agent-cli/introduction

#### 2.5. Playwright logo link returns to homepage

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/docs/intro
    - expect: The Installation page loads
  2. Click the 'Playwright logo Playwright' link in the top navigation
    - expect: The browser navigates back to https://playwright.dev/ and the homepage hero section is visible

#### 2.6. GitHub repository link points to correct URL

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Inspect the href of the 'GitHub repository' link in the top-right navigation
    - expect: The link href is 'https://github.com/microsoft/playwright'

#### 2.7. Discord server link points to correct URL

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Inspect the href of the 'Discord server' link in the top-right navigation
    - expect: The link href is 'https://aka.ms/playwright/discord'

#### 2.8. theme toggle button is present

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Locate the 'Switch between dark and light mode' button in the top navigation
    - expect: The button is visible and accessible
  3. Click the theme toggle button
    - expect: The button state changes (toggling between system/dark/light mode); the page does not reload

#### 2.9. Search button opens search modal

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Click the 'Search (Control+k)' button in the top navigation
    - expect: A search modal or search input becomes visible on the page

#### 2.10. Node.js language switcher button is present

**File:** `tests/playwright-dev/navigation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/
    - expect: The homepage loads
  2. Locate the 'Node.js' button in the top navigation
    - expect: The Node.js language switcher button is visible
  3. Click the 'Node.js' button
    - expect: A dropdown or language options appear offering language variants (e.g., Python, Java, .NET)

### 3. Installation / Getting Started Page

**Seed:** `tests/example.spec.js`

#### 3.1. Installation page title is correct

**File:** `tests/playwright-dev/installation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/docs/intro
    - expect: The page title is 'Installation | Playwright'

#### 3.2. Installation heading is visible

**File:** `tests/playwright-dev/installation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/docs/intro
    - expect: The page loads successfully
  2. Inspect the page for the main heading
    - expect: A heading with the name 'Installation' is visible on the page

#### 3.3. Getting Started sidebar section is expanded

**File:** `tests/playwright-dev/installation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/docs/intro
    - expect: The page loads successfully
  2. Inspect the left sidebar navigation
    - expect: The 'Getting Started' group is expanded and the following sidebar links are visible: 'Installation', 'Writing tests', 'Generating tests', 'Running and debugging tests', 'Trace viewer', 'Setting up CI', 'VS Code'

#### 3.4. Installation page active sidebar link is highlighted

**File:** `tests/playwright-dev/installation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/docs/intro
    - expect: The page loads successfully
  2. Inspect the 'Installation' link in the sidebar
    - expect: The 'Installation' link is marked as the current/active page (e.g., distinct styling or aria-current attribute)

#### 3.5. Writing tests sidebar link navigates correctly

**File:** `tests/playwright-dev/installation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/docs/intro
    - expect: The Installation page loads
  2. Click the 'Writing tests' link in the sidebar
    - expect: The browser navigates to /docs/writing-tests and the page title reflects 'Writing tests'

#### 3.6. Release notes sidebar link is present

**File:** `tests/playwright-dev/installation.spec.ts`

**Steps:**
  1. Navigate to https://playwright.dev/docs/intro
    - expect: The page loads successfully
  2. Inspect the sidebar for the 'Release notes' link
    - expect: The 'Release notes' link is visible in the sidebar and has href '/docs/release-notes'
