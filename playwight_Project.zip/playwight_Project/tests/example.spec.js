// @ts-check
import { test, expect, chromium } from '@playwright/test';
import postData from './data/post-data.json' with { type: 'json' };
import { verifyOAuthToken } from './utils/auth.js';

// test('has title', async ({ page }) => {
//   await page.goto('https://playwright.dev');

//   // Expect a title "to contain" a substring.
//   await expect(page).toHaveTitle(/Playwright/);
// });

test('get started link', async ({ page }, testInfo) => {
  await page.goto('https://playwright.dev');

  await page.getByRole('link', { name: 'Get started' }).click();
  // await page.getByRole('link', { name: 'Installation' }).click();
  
  //await page.screenshot({ path: 'screenshot.png' });
    const screenshot = await page.screenshot();
   testInfo.attach('Example Page', {
       body: screenshot,
       contentType: 'image/png',
   });
//   // Expects page to have a heading with the name of Installation.
//   // await expect(page.getByRole('heading', { name: 'Installation' })).toBeVisible();
//     const dropdownSelector = '//span[@title="Getting Started"]';
 
//   //  await page.click(dropdownSelector);
//   await page.selectOption(dropdownSelector, 'Generating tests');

});

test('capture and attach screenshot', async ({ page }, testInfo) => {
   await page.goto('https://playwright.dev');
   const screenshot = await page.screenshot();
   testInfo.attach('Example Page', {
       body: screenshot,
       contentType: 'image/png',
   });
   await page.goForward();
   await page.goBack();
   await page.reload();
const screenshot1 = await page.screenshot();
testInfo.attach('example1',{body: screenshot1, contentType: 'image/png'});

});

test('get theme-appearance.js API response', async ({ request }) => {
   const response = await request.get('https://etherscan.io/assets/js/theme-appearance.js?v=26.8.1.3');
   
   // Check response status
   expect(response.ok()).toBeTruthy();
   expect(response.status()).toBe(200);
   
   // Get response body as text
   const responseBody = await response.text();
   console.log('Response Status:', response.status());
   console.log('Content-Type:', response.headers()['content-type']);
   console.log('Response Body Length:', responseBody.length);
   console.log('Response Body (first 500 chars):', responseBody.substring(0, 500));
});

test('fetch and verify JSON data from API', async ({ request }) => {
   const response = await request.get('https://jsonplaceholder.typicode.com/users/1');

   expect(response.ok()).toBeTruthy();
   expect(response.status()).toBe(200);
   expect(response.headers()['content-type']).toContain('application/json');

   const data = await response.json();

   // Verify structure and values of the returned JSON
   expect(data).toHaveProperty('id', 1);
   expect(data).toHaveProperty('name', 'Leanne Graham');
   expect(data).toHaveProperty('username', 'Bret');
   expect(data).toHaveProperty('email', 'Sincere@april.biz');
   expect(data.address).toMatchObject({
      street: 'Kulas Light',
      city: 'Gwenborough',
      zipcode: '92998-3874',
   });
   expect(data.company).toHaveProperty('name', 'Romaguera-Crona');
});

test('post JSON data read from file', async ({ request }) => {
   const response = await request.post('https://jsonplaceholder.typicode.com/posts', {
      data: postData,
   });

   expect(response.ok()).toBeTruthy();
   expect(response.status()).toBe(201);

   const data = await response.json();

   // Verify the API echoes back the posted data plus a generated id
   expect(data).toMatchObject(postData);
   expect(data).toHaveProperty('id');
});

test('verify OAuth2.0 token - valid token is accepted', async ({ request }) => {
   const { valid, status, body } = await verifyOAuthToken(request, 'sample-valid-token-123');

   expect(valid).toBeTruthy();
   expect(status).toBe(200);
   expect(body.token).toBe('sample-valid-token-123');
});

test('verify OAuth2.0 token - missing token is rejected', async ({ request }) => {
   const { valid, status } = await verifyOAuthToken(request, '');

   expect(valid).toBeFalsy();
   expect(status).toBe(401);
});



// test('browsercontext test', async ({page}, testInfor) => { 

// const browser = await chromium.launch();
// const context = await browser.newContext();
// const page1 = await context.newPage();
// await page1.goto('https://playwright.dev');
// await expect(page1).toHaveTitle(/Playwright/);
// await page1.frameLocator('iframe').getByRole('link', { name: 'Get started' }).click();

// });
test('example test for screenshot', {
  tag: ['@smoke', '@regression']
}, async ({ page }) => {
 await page.goto('https://playwright.dev');
  const screenshot=await page.screenshot({ path : 'screenshot.png' });
  expect(screenshot).toBeDefined();
  expect(screenshot.length).toBeGreaterThan(0);


});

test('check the attachemnt properlywork or not',{tag:['@app']},async({page})=>{
await page.goto('https://playwright.dev');
const attachment=await page.screenshot({ path: 'attachment.png' });
expect(attachment).toBeDefined();
expect(attachment.length).toBeGreaterThan(0);
});

