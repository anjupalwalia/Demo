// @ts-check

import { test as base, expect } from '@playwright/test';

const loginUrl = process.env.PVR_LOGIN_URL ?? 'https://pvr.qa.advisorcompass.com/cst/';

/**
 * @typedef {{ username?: string, password?: string, url?: string }} LoginOptions
 */

/**
 * @typedef {(options?: LoginOptions) => Promise<void>} LoginFixture
 */

/**
 * @typedef {import('@playwright/test').PlaywrightTestArgs & { login: LoginFixture }} AuthFixtures
 */

/** @type {import('@playwright/test').TestType<AuthFixtures, {}>} */
export const test = base.extend(/** @type {any} */ ({
  /**
   * @param {{ page: import('@playwright/test').Page }} args
   * @param {(login: LoginFixture) => Promise<void>} use
   */
  login: async ({ page }, use) => {
    await use(async (options = {}) => {
      const username = options.username ?? process.env.PVR_USERNAME;
      const password = options.password ?? process.env.PVR_PASSWORD;

      if (!username || !password) {
        throw new Error('Set PVR_USERNAME and PVR_PASSWORD (e.g. in a .env file, see .env.example) before running login tests.');
      }

      await page.goto(options.url ?? loginUrl);
      const userId = page.locator('#userID');
      const passwordField = page.locator('#password');
      const loginButton = page.locator('#loginbtn');

      await userId.waitFor({ state: 'visible' });
      await userId.fill(username);
      await passwordField.fill(password);
      await Promise.all([
        page.waitForLoadState('domcontentloaded'),
        loginButton.click(),
      ]);
    });
  },
}));

export { expect };