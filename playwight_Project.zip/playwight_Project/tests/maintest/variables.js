function myFunction() {
    var myVariable = "Hello";
    var myVariable = "Hello";
    console.log(myVariable);
}
myFunction();
