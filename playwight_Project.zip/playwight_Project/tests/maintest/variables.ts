


function myFunction() {

   let username: any, myVariable: any;
   myVariable= "Hello";
      myVariable = 123;
    //var myVariable = "Hello";
    console.log(myVariable);
}
 //console.log(myVariable);

myFunction();

