// @ts-check
import { test, expect, chromium } from '@playwright/test';
import postData from './data/post-data.json' with { type: 'json' };
import { verifyOAuthToken } from './utils/auth.js';



test('get theme-appearance.js API response', async ({ request }) => {
   const response = await request.get('https://jsonplaceholder.typicode.com/posts', {
      
    data:postData,

   });
   
   expect(response.ok()).toBeTruthy();
   expect(response.status()).toBe(200);

   const data = await response.json();
   const resonceBody =await response.text();

   console.log('Response Body:', resonceBody);
   expect(resonceBody).toBeDefined();
   expect(resonceBody.length).toBeGreaterThan(0);
   
});





