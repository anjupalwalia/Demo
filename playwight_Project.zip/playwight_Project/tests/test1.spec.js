// @ts-check
import { test, expect } from './fixtures/auth.fixture.js';


test('example test', async ({ login, page }) => {
    await login();

    await expect(page).toHaveTitle('Segmentation and Service Model Planner');
});



test('to check the screenshot attached succesfully', async ({ login, page }) => {   
    await login();

    await page.screenshot({ path: 'screenshot.png' });
    expect(await page.screenshot()).toBeDefined();
});