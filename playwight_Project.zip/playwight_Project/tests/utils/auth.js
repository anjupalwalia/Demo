// @ts-check

/**
 * Verifies an OAuth 2.0 bearer token by calling a protected endpoint with it.
 * @param {import('@playwright/test').APIRequestContext} request
 * @param {string} token - the OAuth 2.0 access token to verify
 * @param {string} [url] - protected endpoint that echoes back auth status
 * @returns {Promise<{ valid: boolean, status: number, body: any }>}
 */
export async function verifyOAuthToken(request, token, url = 'https://httpbin.org/bearer') {
  const response = await request.get(url, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });

  const status = response.status();
  let body = null;
  try {
    body = await response.json();
  } catch {
    // response has no JSON body (e.g. 401 with empty body)
  }

  return { valid: status === 200, status, body };
}
